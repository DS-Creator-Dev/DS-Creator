#pragma once

namespace DSC::NitroFS
{
	//void init();
}
