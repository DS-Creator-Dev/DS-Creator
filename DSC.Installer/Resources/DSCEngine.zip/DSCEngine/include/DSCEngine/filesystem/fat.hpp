#pragma once

namespace DSC::FAT
{
	//void init();
}
